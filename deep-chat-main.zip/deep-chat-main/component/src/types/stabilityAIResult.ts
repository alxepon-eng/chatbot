export interface StabilityAITextToImageResult {
  artifacts: {base64: string}[];
  message?: string;
}
