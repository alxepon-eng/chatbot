export type GenericObject<T = string> = {[key: string]: T};
