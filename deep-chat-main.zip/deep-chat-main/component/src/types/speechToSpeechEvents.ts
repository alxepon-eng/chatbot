export interface SpeechToSpeechEvents {
  started?: () => void;
  stopped?: () => void;
}
