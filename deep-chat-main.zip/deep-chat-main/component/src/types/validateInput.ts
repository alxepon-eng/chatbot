export type ValidateInput = (text?: string, files?: File[]) => boolean;
